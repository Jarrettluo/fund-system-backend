package com.example.fundsystembackend.service;

import com.example.fundsystembackend.entity.Chinamutualfundmanager;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author luojiarui
 * @since 2021-12-09
 */
public interface ChinaMutualFundManagerService extends IService<Chinamutualfundmanager> {

}
